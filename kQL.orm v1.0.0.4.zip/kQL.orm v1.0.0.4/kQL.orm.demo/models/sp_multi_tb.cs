
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-13 09:17:10*/
using System;
using System.ComponentModel; 

namespace kQL.orm.demo.models
{
    public class sp_multi_tb
    {
 
    }

}
