
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-13 09:17:12*/
using System;
using System.ComponentModel; 
using kQL.orm.expr;

namespace kQL.orm.demo.models
{
    public class Dy_UDF
    {
public static DyXTable fn_test1 ( ) { throw new Exception();} public class FModel_fn_test1 { public String 账号{get;set;} public String 用户名{get;set;} }
public static DyXTable fn_test2 ( String @账号,String @用户名 ) { throw new Exception();} public class FModel_fn_test2 { public String 账号{get;set;} public String 用户名{get;set;} }
public static String fn_IsDateout ( DateTime @BDate ) { throw new Exception();}
public static String fn_IsOut ( Int32 @val ) { throw new Exception();} 
    }

}
