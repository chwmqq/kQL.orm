
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-22 13:36:23*/
using System;
using System.ComponentModel; 

namespace kQL.orm.demo.models
{
    public class sp_add_order2
    {
	public Guid 订单号 {get;set;}
	public String 订单名称 {get;set;}
	public String 账号 {get;set;}
	public Decimal 金额 {get;set;}
 
    }

}
