
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-06 15:15:13*/
using System;
using System.ComponentModel; 

namespace kQL.orm.demo.models
{
    public class v_user_order
    {
	public String 订单名称 {get;set;}
	public Guid 订单ID {get;set;}
	public Int32 购买数量 {get;set;}
	public String 账号 {get;set;}
 
    }

}
