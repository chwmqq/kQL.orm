
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-10 00:01:09*/
using System;
using System.ComponentModel; 

namespace kQL.orm.demo.remotemodels
{
    public class tb_order_info
    {
	public Guid 订单ID {get;set;}
	public String 账号 {get;set;}
	public Int32 明细数量 {get;set;}
	public Decimal 总金额Max {get;set;}
	public Decimal 总金额Min {get;set;}
	public Decimal 总金额Sum {get;set;}
	public Decimal 总金额Avg {get;set;}
	public Decimal R金额 {get;set;}
 
    }

}
