
/* 本代码由kQL.orm.cmdTool工具自动生成  
   contact:chwmqq@126.com 
   created time:2017-06-09 23:58:48*/
using System;
using System.ComponentModel; 

namespace kQL.orm.demo.models
{
    public class sp_multi_tb
    {
 
    }

}
